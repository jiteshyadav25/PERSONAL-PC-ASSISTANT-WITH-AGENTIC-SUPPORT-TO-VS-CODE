```jsx
import React from 'react';

const Navbar = () => {
  return (
    <nav className="bg-gray-800 text-white p-4">
      <ul className="flex space-x-4">
        <li><a href="/" className="hover:text-gray-300">Home</a></li>
        <li><a href="/contact" className="hover:text-gray-300">Contact</a></li>
        <li><a href="/aboutus" className="hover:text-gray-300">About Us</a></li>
        <li><a href="/address" className="hover:text-gray-300">Address</a></li>
      </ul>
    </nav>
  );
};

export default Navbar;
```
